-- Productos que los merenderos piden con "Otros" y el admin revisa antes de sumarlos al catálogo.
-- Hibernate (ddl-auto=update) lo aplica solo al arrancar; este script es para correrlo a mano en Supabase si se prefiere.
ALTER TABLE public.alimentos ADD COLUMN IF NOT EXISTS pendiente boolean DEFAULT false NOT NULL;
ALTER TABLE public.alimentos ADD COLUMN IF NOT EXISTS sugerido_por_merendero_id bigint;
