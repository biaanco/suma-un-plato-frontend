package com.sumaunplato;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Pruebas automaticas de autenticacion y autorizacion.
 * Usan los usuarios de prueba que crea DataInitializer sobre una base H2 en memoria.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class SeguridadTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper mapper;

    private String loginJson(String email, String password) {
        return "{\"email\":\"" + email + "\",\"password\":\"" + password + "\"}";
    }

    private String tokenDe(String email, String password) throws Exception {
        String respuesta = mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(loginJson(email, password)))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        JsonNode json = mapper.readTree(respuesta);
        return json.get("token").asText();
    }

    @Test
    @DisplayName("1. Login correcto devuelve 200, el rol y un token")
    void loginCorrecto() throws Exception {
        mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(loginJson("admin@sumaunplato.org", "admin123")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rol").value("admin"))
                .andExpect(jsonPath("$.token").isNotEmpty());
    }

    @Test
    @DisplayName("2. Login con contrasena incorrecta devuelve 401")
    void loginFallido() throws Exception {
        mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(loginJson("admin@sumaunplato.org", "claveIncorrecta")))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error").value("Email o contrasena incorrectos"));
    }

    @Test
    @DisplayName("3. Ruta protegida sin token devuelve 401")
    void sinTokenDevuelve401() throws Exception {
        mvc.perform(get("/api/panel/dashboard"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("4. Donante intentando entrar al panel de admin devuelve 403")
    void donanteEnPanelDevuelve403() throws Exception {
        String token = tokenDe("maria@example.com", "maria123");
        mvc.perform(get("/api/panel/dashboard")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("5. Admin con token entra al panel y recibe 200")
    void adminEnPanelDevuelve200() throws Exception {
        String token = tokenDe("admin@sumaunplato.org", "admin123");
        mvc.perform(get("/api/panel/dashboard")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());
    }
}
