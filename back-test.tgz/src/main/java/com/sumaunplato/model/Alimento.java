package com.sumaunplato.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "alimentos")
public class Alimento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    private String categoria;

    private String unidad;

    private String icono;

    private boolean activo = true;

    // Producto que cargó un merendero con "Otros" y todavía no revisó el admin
    @Column(columnDefinition = "boolean default false not null")
    private boolean pendiente = false;

    private Long sugeridoPorMerenderoId;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public String getUnidad() { return unidad; }
    public void setUnidad(String unidad) { this.unidad = unidad; }

    public String getIcono() { return icono; }
    public void setIcono(String icono) { this.icono = icono; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public boolean isPendiente() { return pendiente; }
    public void setPendiente(boolean pendiente) { this.pendiente = pendiente; }

    public Long getSugeridoPorMerenderoId() { return sugeridoPorMerenderoId; }
    public void setSugeridoPorMerenderoId(Long sugeridoPorMerenderoId) { this.sugeridoPorMerenderoId = sugeridoPorMerenderoId; }
}
