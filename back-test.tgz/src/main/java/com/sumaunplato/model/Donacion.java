package com.sumaunplato.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "donaciones")
public class Donacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long donanteId;

    private String estado = "registrada";

    private String nota;

    private LocalDateTime creadoEn = LocalDateTime.now();

    private LocalDateTime ingresadoEn;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getDonanteId() { return donanteId; }
    public void setDonanteId(Long donanteId) { this.donanteId = donanteId; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getNota() { return nota; }
    public void setNota(String nota) { this.nota = nota; }

    public LocalDateTime getCreadoEn() { return creadoEn; }
    public void setCreadoEn(LocalDateTime creadoEn) { this.creadoEn = creadoEn; }

    public LocalDateTime getIngresadoEn() { return ingresadoEn; }
    public void setIngresadoEn(LocalDateTime ingresadoEn) { this.ingresadoEn = ingresadoEn; }
}
