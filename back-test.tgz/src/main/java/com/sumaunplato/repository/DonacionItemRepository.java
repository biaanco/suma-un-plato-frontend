package com.sumaunplato.repository;

import com.sumaunplato.model.DonacionItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DonacionItemRepository extends JpaRepository<DonacionItem, Long> {
    List<DonacionItem> findByDonacionId(Long donacionId);
}
