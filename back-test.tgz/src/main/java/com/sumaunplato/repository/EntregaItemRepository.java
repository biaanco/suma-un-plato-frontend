package com.sumaunplato.repository;

import com.sumaunplato.model.EntregaItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EntregaItemRepository extends JpaRepository<EntregaItem, Long> {
    List<EntregaItem> findByEntregaId(Long entregaId);
}
