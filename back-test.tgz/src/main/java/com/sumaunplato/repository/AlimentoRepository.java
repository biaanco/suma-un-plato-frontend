package com.sumaunplato.repository;

import com.sumaunplato.model.Alimento;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AlimentoRepository extends JpaRepository<Alimento, Long> {
    List<Alimento> findByActivoTrueOrderByNombreAsc();
    List<Alimento> findByPendienteTrueOrderByIdAsc();
}
