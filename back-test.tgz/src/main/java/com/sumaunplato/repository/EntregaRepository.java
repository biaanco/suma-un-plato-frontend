package com.sumaunplato.repository;

import com.sumaunplato.model.Entrega;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EntregaRepository extends JpaRepository<Entrega, Long> {
    List<Entrega> findByEstadoOrderByCreadoEnDesc(String estado);
    List<Entrega> findByMerenderoIdAndEstadoOrderByCreadoEnDesc(Long merenderoId, String estado);
}
