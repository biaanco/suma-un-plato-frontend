package com.sumaunplato.repository;

import com.sumaunplato.model.Lote;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LoteRepository extends JpaRepository<Lote, Long> {
    List<Lote> findByActivoTrueAndCantidadGreaterThan(double cantidad);
    List<Lote> findByAlimentoIdAndActivoTrueAndCantidadGreaterThan(Long alimentoId, double cantidad);
    List<Lote> findByAlimentoId(Long alimentoId);
}
