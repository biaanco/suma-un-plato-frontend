package com.sumaunplato.repository;

import com.sumaunplato.model.PlanillaNecesidad;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PlanillaNecesidadRepository extends JpaRepository<PlanillaNecesidad, Long> {
    List<PlanillaNecesidad> findByMerenderoId(Long merenderoId);
    List<PlanillaNecesidad> findByAlimentoId(Long alimentoId);
    List<PlanillaNecesidad> findByMerenderoIdAndEstadoNot(Long merenderoId, String estado);
    List<PlanillaNecesidad> findByEstadoNot(String estado);
    List<PlanillaNecesidad> findByMerenderoIdAndAlimentoIdAndEstadoNot(Long merenderoId, Long alimentoId, String estado);
}
