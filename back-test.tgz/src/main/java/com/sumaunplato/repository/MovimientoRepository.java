package com.sumaunplato.repository;

import com.sumaunplato.model.Movimiento;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MovimientoRepository extends JpaRepository<Movimiento, Long> {
    List<Movimiento> findTop200ByOrderByCreadoEnDesc();
    List<Movimiento> findTop200ByTipoOrderByCreadoEnDesc(String tipo);
    List<Movimiento> findByTipo(String tipo);
}
