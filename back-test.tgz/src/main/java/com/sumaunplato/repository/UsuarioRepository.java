package com.sumaunplato.repository;

import com.sumaunplato.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByEmail(String email);
    Optional<Usuario> findByResetToken(String resetToken);
    boolean existsByEmail(String email);
    boolean existsByDni(String dni);
    List<Usuario> findByRol(String rol);

}
