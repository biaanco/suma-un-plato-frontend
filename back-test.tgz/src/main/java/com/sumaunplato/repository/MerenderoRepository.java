package com.sumaunplato.repository;

import com.sumaunplato.model.Merendero;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface MerenderoRepository extends JpaRepository<Merendero, Long> {
    List<Merendero> findByActivoTrueOrderByNombreAsc();
    List<Merendero> findAllByOrderByActivoDescNombreAsc();
    Optional<Merendero> findByUsuarioIdAndActivoTrue(Long usuarioId);
    long countByActivoTrue();
}
