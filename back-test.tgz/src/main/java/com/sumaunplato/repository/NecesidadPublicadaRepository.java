package com.sumaunplato.repository;

import com.sumaunplato.model.NecesidadPublicada;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface NecesidadPublicadaRepository extends JpaRepository<NecesidadPublicada, Long> {
    List<NecesidadPublicada> findByActivaTrue();
    Optional<NecesidadPublicada> findByAlimentoIdAndActivaTrue(Long alimentoId);
}
