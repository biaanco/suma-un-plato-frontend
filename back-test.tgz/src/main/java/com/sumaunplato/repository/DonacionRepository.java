package com.sumaunplato.repository;

import com.sumaunplato.model.Donacion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DonacionRepository extends JpaRepository<Donacion, Long> {
    List<Donacion> findByDonanteIdOrderByCreadoEnDesc(Long donanteId);
    List<Donacion> findByEstadoOrderByCreadoEnAsc(String estado);
    long countByEstado(String estado);
}
