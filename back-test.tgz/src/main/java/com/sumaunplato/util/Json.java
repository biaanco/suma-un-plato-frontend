package com.sumaunplato.util;

import java.util.LinkedHashMap;
import java.util.Map;

public class Json {

    public static Map<String, Object> obj() {
        return new LinkedHashMap<>();
    }

    public static Map<String, Object> error(String mensaje) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("error", mensaje);
        return m;
    }

    public static Map<String, Object> ok(String mensaje) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("ok", true);
        m.put("mensaje", mensaje);
        return m;
    }
}
