package com.sumaunplato.controller;

import com.sumaunplato.dto.EntregaRequest;
import com.sumaunplato.dto.IngresoRequest;
import com.sumaunplato.model.Alimento;
import com.sumaunplato.model.Donacion;
import com.sumaunplato.model.DonacionItem;
import com.sumaunplato.model.Entrega;
import com.sumaunplato.model.Lote;
import com.sumaunplato.model.Merendero;
import com.sumaunplato.model.Movimiento;
import com.sumaunplato.model.NecesidadPublicada;
import com.sumaunplato.model.PlanillaNecesidad;
import com.sumaunplato.model.Usuario;
import com.sumaunplato.repository.AlimentoRepository;
import com.sumaunplato.repository.DonacionItemRepository;
import com.sumaunplato.repository.DonacionRepository;
import com.sumaunplato.repository.EntregaRepository;
import com.sumaunplato.repository.LoteRepository;
import com.sumaunplato.repository.MerenderoRepository;
import com.sumaunplato.repository.MovimientoRepository;
import com.sumaunplato.repository.NecesidadPublicadaRepository;
import com.sumaunplato.repository.PlanillaNecesidadRepository;
import com.sumaunplato.repository.UsuarioRepository;
import com.sumaunplato.service.DepositoService;
import com.sumaunplato.util.Json;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Tag(name = "Panel", description = "Panel del coordinador: dashboard, stock, ingresos y entregas FEFO")
@RestController
@RequestMapping("/api/panel")
public class PanelController {

    private final DepositoService deposito;
    private final AlimentoRepository alimentoRepo;
    private final LoteRepository loteRepo;
    private final DonacionRepository donacionRepo;
    private final DonacionItemRepository donacionItemRepo;
    private final NecesidadPublicadaRepository necesidadRepo;
    private final PlanillaNecesidadRepository planillaRepo;
    private final MerenderoRepository merenderoRepo;
    private final EntregaRepository entregaRepo;
    private final MovimientoRepository movimientoRepo;
    private final UsuarioRepository usuarioRepo;

    public PanelController(DepositoService deposito, AlimentoRepository alimentoRepo, LoteRepository loteRepo,
                           DonacionRepository donacionRepo, DonacionItemRepository donacionItemRepo,
                           NecesidadPublicadaRepository necesidadRepo, PlanillaNecesidadRepository planillaRepo,
                           MerenderoRepository merenderoRepo, EntregaRepository entregaRepo,
                           MovimientoRepository movimientoRepo, UsuarioRepository usuarioRepo) {
        this.deposito = deposito;
        this.alimentoRepo = alimentoRepo;
        this.loteRepo = loteRepo;
        this.donacionRepo = donacionRepo;
        this.donacionItemRepo = donacionItemRepo;
        this.necesidadRepo = necesidadRepo;
        this.planillaRepo = planillaRepo;
        this.merenderoRepo = merenderoRepo;
        this.entregaRepo = entregaRepo;
        this.movimientoRepo = movimientoRepo;
        this.usuarioRepo = usuarioRepo;
    }

    private Map<String, Object> semaforo(LocalDate vencimiento) {
        Map<String, Object> m = Json.obj();
        if (vencimiento == null) {
            m.put("clase", "neutro");
            m.put("dias", null);
            m.put("texto", "Sin vencimiento");
            return m;
        }
        long dias = ChronoUnit.DAYS.between(LocalDate.now(), vencimiento);
        String clase;
        String texto;
        if (dias <= 3) {
            clase = "rojo";
            texto = dias < 0 ? "Vencido" : (dias == 0 ? "Vence hoy" : "Vence en " + dias + " d");
        } else if (dias <= 15) {
            clase = "ambar";
            texto = "Vence en " + dias + " d";
        } else {
            clase = "verde";
            texto = "Vence en " + dias + " d";
        }
        m.put("clase", clase);
        m.put("dias", dias);
        m.put("texto", texto);
        return m;
    }

    private String nombreAlimento(Long id) {
        Alimento a = alimentoRepo.findById(id).orElse(null);
        return a != null ? a.getNombre() : "";
    }

    @GetMapping("/dashboard")
    public Map<String, Object> dashboard() {
        double stockTotal = 0;
        for (Lote l : loteRepo.findByActivoTrueAndCantidadGreaterThan(0)) {
            stockTotal += l.getCantidad();
        }
        long porRevisar = donacionRepo.countByEstado("registrada");

        List<Map<String, Object>> semaforoLotes = new ArrayList<>();
        List<Lote> lotesConVenc = new ArrayList<>();
        for (Lote l : loteRepo.findByActivoTrueAndCantidadGreaterThan(0)) {
            if (l.getVencimiento() != null) {
                lotesConVenc.add(l);
            }
        }
        lotesConVenc.sort(Comparator.comparing(Lote::getVencimiento));
        int porVencer = 0;
        for (Lote l : lotesConVenc) {
            Map<String, Object> s = semaforo(l.getVencimiento());
            long dias = (Long) s.get("dias");
            if (dias <= 15) {
                porVencer++;
            }
            Map<String, Object> m = Json.obj();
            m.put("id", l.getId());
            m.put("nombre", nombreAlimento(l.getAlimentoId()));
            m.put("icono", iconoAlimento(l.getAlimentoId()));
            m.put("cantidad", l.getCantidad());
            m.put("unidad", unidadAlimento(l.getAlimentoId()));
            m.put("semaforo", s);
            if (semaforoLotes.size() < 12) {
                semaforoLotes.add(m);
            }
        }

        List<Map<String, Object>> pendientes = new ArrayList<>();
        int urgentesSinCubrir = 0;
        for (NecesidadPublicada n : necesidadRepo.findByActivaTrue()) {
            double cubierto = deposito.cubiertoNecesidad(n.getAlimentoId());
            if (cubierto < n.getCantidadObjetivo()) {
                if (n.isUrgente()) {
                    urgentesSinCubrir++;
                }
                int pct = n.getCantidadObjetivo() > 0 ? (int) Math.min(100, Math.round(cubierto / n.getCantidadObjetivo() * 100)) : 0;
                Map<String, Object> m = Json.obj();
                m.put("nombre", nombreAlimento(n.getAlimentoId()));
                m.put("unidad", unidadAlimento(n.getAlimentoId()));
                m.put("urgente", n.isUrgente());
                m.put("cubierto", cubierto);
                m.put("objetivo", n.getCantidadObjetivo());
                m.put("pct", pct);
                pendientes.add(m);
            }
        }

        Map<String, Object> salida = Json.obj();
        salida.put("stockTotal", stockTotal);
        salida.put("porRevisar", porRevisar);
        salida.put("porVencer", porVencer);
        salida.put("urgentesSinCubrir", urgentesSinCubrir);
        salida.put("semaforo", semaforoLotes);
        salida.put("necesidadesPendientes", pendientes);
        return salida;
    }

    @GetMapping("/revisar")
    public List<Map<String, Object>> revisar() {
        List<Map<String, Object>> salida = new ArrayList<>();
        for (Donacion d : donacionRepo.findByEstadoOrderByCreadoEnAsc("registrada")) {
            Usuario donante = usuarioRepo.findById(d.getDonanteId()).orElse(null);
            Map<String, Object> m = Json.obj();
            m.put("id", d.getId());
            m.put("donante", donante != null ? donante.getNombre() : "");
            m.put("tipoDonante", donante != null ? donante.getTipoDonante() : "");
            m.put("creadoEn", d.getCreadoEn());
            m.put("nota", d.getNota());
            List<Map<String, Object>> items = new ArrayList<>();
            for (DonacionItem it : donacionItemRepo.findByDonacionId(d.getId())) {
                Alimento a = alimentoRepo.findById(it.getAlimentoId()).orElse(null);
                Map<String, Object> mi = Json.obj();
                mi.put("alimentoId", it.getAlimentoId());
                mi.put("nombre", a != null ? a.getNombre() : "");
                mi.put("icono", a != null ? a.getIcono() : "bag");
                mi.put("categoria", a != null ? a.getCategoria() : "");
                mi.put("cantidad", it.getCantidad());
                mi.put("unidad", it.getUnidad());
                items.add(mi);
            }
            m.put("items", items);
            salida.add(m);
        }
        return salida;
    }

    @PostMapping("/revisar/confirmar")
    public ResponseEntity<Map<String, Object>> confirmarIngreso(@RequestBody IngresoRequest req) {
        try {
            deposito.confirmarIngreso(req);
            return ResponseEntity.ok(Json.ok("Donación ingresada al stock"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Json.error("No se pudo confirmar el ingreso"));
        }
    }

    @GetMapping("/stock")
    public List<Map<String, Object>> stock(@RequestParam(required = false) String cat,
                                           @RequestParam(required = false) String q) {
        List<Map<String, Object>> salida = new ArrayList<>();
        for (Lote l : loteRepo.findByActivoTrueAndCantidadGreaterThan(0)) {
            Alimento a = alimentoRepo.findById(l.getAlimentoId()).orElse(null);
            if (a == null) {
                continue;
            }
            if (cat != null && !cat.isEmpty() && !a.getCategoria().equals(cat)) {
                continue;
            }
            if (q != null && !q.isEmpty() && !a.getNombre().toLowerCase().contains(q.toLowerCase())) {
                continue;
            }
            Map<String, Object> m = Json.obj();
            m.put("id", l.getId());
            m.put("nombre", a.getNombre());
            m.put("icono", a.getIcono());
            m.put("categoria", a.getCategoria());
            m.put("cantidad", l.getCantidad());
            m.put("unidad", a.getUnidad());
            m.put("origen", l.getOrigenDonacionId());
            m.put("vencimiento", l.getVencimiento());
            m.put("semaforo", semaforo(l.getVencimiento()));
            salida.add(m);
        }
        salida.sort(Comparator.comparing(x -> (String) x.get("nombre")));
        return salida;
    }

    @PostMapping("/stock/ajustar")
    public ResponseEntity<Map<String, Object>> ajustar(@RequestBody Map<String, Object> datos) {
        Long loteId = Long.valueOf(datos.get("loteId").toString());
        double nueva = Double.parseDouble(datos.get("cantidad").toString());
        Long usuarioId = datos.get("usuarioId") != null ? Long.valueOf(datos.get("usuarioId").toString()) : null;
        Lote l = loteRepo.findById(loteId).orElse(null);
        if (l == null) {
            return ResponseEntity.badRequest().body(Json.error("Lote no encontrado"));
        }
        double diff = nueva - l.getCantidad();
        l.setCantidad(nueva);
        l.setActivo(nueva > 0);
        loteRepo.save(l);
        deposito.registrarMovimiento("ajuste", l.getAlimentoId(), l.getId(), diff,
                "Ajuste manual de lote #" + l.getId(), usuarioId);
        return ResponseEntity.ok(Json.ok("Lote ajustado"));
    }

    @GetMapping("/planillas")
    public Map<String, Object> planillas() {
        Map<Long, double[]> agregado = new HashMap<>();
        Map<Long, String> urgAgg = new HashMap<>();
        for (PlanillaNecesidad p : planillaRepo.findByEstadoNot("cubierta")) {
            agregado.merge(p.getAlimentoId(), new double[]{p.getCantidad()}, (a, b) -> new double[]{a[0] + b[0]});
            String actual = urgAgg.getOrDefault(p.getAlimentoId(), "baja");
            urgAgg.put(p.getAlimentoId(), mayorUrgencia(actual, p.getUrgencia()));
        }
        List<Map<String, Object>> agg = new ArrayList<>();
        for (Map.Entry<Long, double[]> e : agregado.entrySet()) {
            Alimento a = alimentoRepo.findById(e.getKey()).orElse(null);
            Map<String, Object> m = Json.obj();
            m.put("nombre", a != null ? a.getNombre() : "");
            m.put("unidad", a != null ? a.getUnidad() : "");
            m.put("total", e.getValue()[0]);
            m.put("urgencia", urgAgg.get(e.getKey()));
            agg.add(m);
        }

        List<Map<String, Object>> porMerendero = new ArrayList<>();
        for (Merendero mr : merenderoRepo.findByActivoTrueOrderByNombreAsc()) {
            Map<String, Object> bloque = Json.obj();
            bloque.put("nombre", mr.getNombre());
            bloque.put("referente", mr.getReferente());
            bloque.put("horarios", mr.getHorarios());
            List<Map<String, Object>> items = new ArrayList<>();
            for (PlanillaNecesidad p : planillaRepo.findByMerenderoId(mr.getId())) {
                Alimento a = alimentoRepo.findById(p.getAlimentoId()).orElse(null);
                Map<String, Object> m = Json.obj();
                m.put("nombre", a != null ? a.getNombre() : "");
                m.put("unidad", a != null ? a.getUnidad() : "");
                m.put("cantidad", p.getCantidad());
                m.put("urgencia", p.getUrgencia());
                m.put("estado", p.getEstado());
                items.add(m);
            }
            bloque.put("items", items);
            porMerendero.add(bloque);
        }

        Map<String, Object> salida = Json.obj();
        salida.put("agregado", agg);
        salida.put("porMerendero", porMerendero);
        return salida;
    }

    @GetMapping("/publicadas")
    public List<Map<String, Object>> publicadas() {
        List<Map<String, Object>> salida = new ArrayList<>();
        for (NecesidadPublicada n : necesidadRepo.findByActivaTrue()) {
            Alimento a = alimentoRepo.findById(n.getAlimentoId()).orElse(null);
            if (a == null) {
                continue;
            }
            double cubierto = deposito.cubiertoNecesidad(a.getId());
            int pct = n.getCantidadObjetivo() > 0 ? (int) Math.min(100, Math.round(cubierto / n.getCantidadObjetivo() * 100)) : 0;
            Map<String, Object> m = Json.obj();
            m.put("id", n.getId());
            m.put("nombre", a.getNombre());
            m.put("icono", a.getIcono());
            m.put("categoria", a.getCategoria());
            m.put("unidad", a.getUnidad());
            m.put("objetivo", n.getCantidadObjetivo());
            m.put("cubierto", cubierto);
            m.put("pct", pct);
            m.put("urgente", n.isUrgente());
            salida.add(m);
        }
        return salida;
    }

    @PostMapping("/publicar")
    public ResponseEntity<Map<String, Object>> publicar(@RequestBody Map<String, Object> datos) {
        Long alimentoId = Long.valueOf(datos.get("alimentoId").toString());
        double objetivo = Double.parseDouble(datos.get("objetivo").toString());
        boolean urgente = Boolean.parseBoolean(String.valueOf(datos.getOrDefault("urgente", false)));
        if (objetivo <= 0) {
            return ResponseEntity.badRequest().body(Json.error("La cantidad objetivo debe ser mayor a 0"));
        }
        NecesidadPublicada n = necesidadRepo.findByAlimentoIdAndActivaTrue(alimentoId).orElse(new NecesidadPublicada());
        n.setAlimentoId(alimentoId);
        n.setCantidadObjetivo(objetivo);
        n.setUrgente(urgente);
        n.setActiva(true);
        necesidadRepo.save(n);
        return ResponseEntity.ok(Json.ok("Necesidad publicada"));
    }

    @PostMapping("/publicar/quitar")
    public ResponseEntity<Map<String, Object>> quitarPublicada(@RequestBody Map<String, Object> datos) {
        Long id = Long.valueOf(datos.get("id").toString());
        necesidadRepo.findById(id).ifPresent(n -> {
            n.setActiva(false);
            necesidadRepo.save(n);
        });
        return ResponseEntity.ok(Json.ok("Necesidad retirada"));
    }

    @PostMapping("/publicar/urgente")
    public ResponseEntity<Map<String, Object>> alternarUrgente(@RequestBody Map<String, Object> datos) {
        Long id = Long.valueOf(datos.get("id").toString());
        necesidadRepo.findById(id).ifPresent(n -> {
            n.setUrgente(!n.isUrgente());
            necesidadRepo.save(n);
        });
        return ResponseEntity.ok(Json.ok("Actualizado"));
    }

    @GetMapping("/entrega/necesidades/{merenderoId}")
    public List<Map<String, Object>> entregaNecesidades(@PathVariable Long merenderoId) {
        List<Map<String, Object>> salida = new ArrayList<>();
        for (PlanillaNecesidad p : planillaRepo.findByMerenderoIdAndEstadoNot(merenderoId, "cubierta")) {
            Alimento a = alimentoRepo.findById(p.getAlimentoId()).orElse(null);
            if (a == null) {
                continue;
            }
            List<Lote> lotes = new ArrayList<>(loteRepo.findByAlimentoIdAndActivoTrueAndCantidadGreaterThan(a.getId(), 0));
            lotes.sort(DepositoService::ordenFefo);
            double disponible = 0;
            List<Map<String, Object>> lotesInfo = new ArrayList<>();
            for (Lote l : lotes) {
                disponible += l.getCantidad();
                Map<String, Object> ml = Json.obj();
                ml.put("id", l.getId());
                ml.put("cantidad", l.getCantidad());
                ml.put("vencimiento", l.getVencimiento());
                ml.put("semaforo", semaforo(l.getVencimiento()));
                lotesInfo.add(ml);
            }
            Map<String, Object> m = Json.obj();
            m.put("alimentoId", a.getId());
            m.put("nombre", a.getNombre());
            m.put("icono", a.getIcono());
            m.put("unidad", a.getUnidad());
            m.put("pedido", p.getCantidad());
            m.put("urgencia", p.getUrgencia());
            m.put("disponible", disponible);
            m.put("sugerido", Math.min(p.getCantidad(), disponible));
            m.put("lotes", lotesInfo);
            salida.add(m);
        }
        return salida;
    }

    @PostMapping("/entrega/preparar")
    public ResponseEntity<Map<String, Object>> prepararEntrega(@RequestBody EntregaRequest req) {
        try {
            Entrega e = deposito.prepararEntrega(req);
            Map<String, Object> ok = Json.ok("Entrega preparada por FEFO. El stock se descontó.");
            ok.put("entregaId", e.getId());
            return ResponseEntity.ok(ok);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Json.error("No se pudo preparar la entrega"));
        }
    }

    @GetMapping("/entrega/pendientes")
    public List<Map<String, Object>> entregasPendientes() {
        List<Map<String, Object>> salida = new ArrayList<>();
        for (Entrega e : entregaRepo.findByEstadoOrderByCreadoEnDesc("preparada")) {
            Merendero mr = merenderoRepo.findById(e.getMerenderoId()).orElse(null);
            Map<String, Object> m = Json.obj();
            m.put("id", e.getId());
            m.put("merendero", mr != null ? mr.getNombre() : "");
            m.put("creadoEn", e.getCreadoEn());
            salida.add(m);
        }
        return salida;
    }

    @GetMapping("/historial")
    public Map<String, Object> historial(@RequestParam(required = false) String tipo) {
        Map<Long, double[]> donado = new HashMap<>();
        Map<Long, double[]> entregado = new HashMap<>();
        for (Movimiento mv : movimientoRepo.findByTipo("ingreso")) {
            if (mv.getAlimentoId() != null && mv.getCantidad() != null) {
                donado.merge(mv.getAlimentoId(), new double[]{mv.getCantidad()}, (a, b) -> new double[]{a[0] + b[0]});
            }
        }
        for (Movimiento mv : movimientoRepo.findByTipo("egreso")) {
            if (mv.getAlimentoId() != null && mv.getCantidad() != null) {
                entregado.merge(mv.getAlimentoId(), new double[]{mv.getCantidad()}, (a, b) -> new double[]{a[0] + b[0]});
            }
        }

        List<Movimiento> movs;
        if (tipo != null && !tipo.isEmpty()) {
            movs = movimientoRepo.findTop200ByTipoOrderByCreadoEnDesc(tipo);
        } else {
            movs = movimientoRepo.findTop200ByOrderByCreadoEnDesc();
        }
        List<Map<String, Object>> movimientos = new ArrayList<>();
        for (Movimiento mv : movs) {
            Usuario u = mv.getUsuarioId() != null ? usuarioRepo.findById(mv.getUsuarioId()).orElse(null) : null;
            Map<String, Object> m = Json.obj();
            m.put("fecha", mv.getCreadoEn());
            m.put("tipo", mv.getTipo());
            m.put("alimento", mv.getAlimentoId() != null ? nombreAlimento(mv.getAlimentoId()) : "");
            m.put("cantidad", mv.getCantidad());
            m.put("detalle", mv.getDetalle());
            m.put("usuario", u != null ? u.getNombre() : "");
            movimientos.add(m);
        }

        Map<String, Object> salida = Json.obj();
        salida.put("donado", reporte(donado));
        salida.put("entregado", reporte(entregado));
        salida.put("movimientos", movimientos);
        return salida;
    }

    private List<Map<String, Object>> reporte(Map<Long, double[]> datos) {
        List<Map<String, Object>> lista = new ArrayList<>();
        for (Map.Entry<Long, double[]> e : datos.entrySet()) {
            Alimento a = alimentoRepo.findById(e.getKey()).orElse(null);
            Map<String, Object> m = Json.obj();
            m.put("nombre", a != null ? a.getNombre() : "");
            m.put("unidad", a != null ? a.getUnidad() : "");
            m.put("total", e.getValue()[0]);
            lista.add(m);
        }
        lista.sort(Comparator.comparingDouble((Map<String, Object> x) -> ((Number) x.get("total")).doubleValue()).reversed());
        return lista;
    }

    private String iconoAlimento(Long id) {
        Alimento a = alimentoRepo.findById(id).orElse(null);
        return a != null ? a.getIcono() : "bag";
    }

    private String unidadAlimento(Long id) {
        Alimento a = alimentoRepo.findById(id).orElse(null);
        return a != null ? a.getUnidad() : "u";
    }

    private String mayorUrgencia(String a, String b) {
        return nivel(b) > nivel(a) ? b : a;
    }

    private int nivel(String u) {
        if ("alta".equals(u)) return 3;
        if ("media".equals(u)) return 2;
        return 1;
    }
}
