package com.sumaunplato.controller;

import com.sumaunplato.model.Alimento;
import com.sumaunplato.model.Lote;
import com.sumaunplato.model.NecesidadPublicada;
import com.sumaunplato.repository.AlimentoRepository;
import com.sumaunplato.repository.EntregaRepository;
import com.sumaunplato.repository.LoteRepository;
import com.sumaunplato.repository.MerenderoRepository;
import com.sumaunplato.repository.NecesidadPublicadaRepository;
import com.sumaunplato.service.DepositoService;
import com.sumaunplato.util.Json;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

@Tag(name = "Publico", description = "Datos que ve cualquier visitante: necesidades y estadisticas")
@RestController
@RequestMapping("/api/publico")
public class PublicoController {

    private final NecesidadPublicadaRepository necesidadRepo;
    private final AlimentoRepository alimentoRepo;
    private final LoteRepository loteRepo;
    private final MerenderoRepository merenderoRepo;
    private final EntregaRepository entregaRepo;
    private final DepositoService deposito;

    public PublicoController(NecesidadPublicadaRepository necesidadRepo, AlimentoRepository alimentoRepo,
                             LoteRepository loteRepo, MerenderoRepository merenderoRepo,
                             EntregaRepository entregaRepo, DepositoService deposito) {
        this.necesidadRepo = necesidadRepo;
        this.alimentoRepo = alimentoRepo;
        this.loteRepo = loteRepo;
        this.merenderoRepo = merenderoRepo;
        this.entregaRepo = entregaRepo;
        this.deposito = deposito;
    }

    @GetMapping("/necesidades")
    public List<Map<String, Object>> necesidades() {
        List<Map<String, Object>> salida = new ArrayList<>();
        for (NecesidadPublicada n : necesidadRepo.findByActivaTrue()) {
            Alimento a = alimentoRepo.findById(n.getAlimentoId()).orElse(null);
            if (a == null) {
                continue;
            }
            double cubierto = deposito.cubiertoNecesidad(a.getId());
            double objetivo = n.getCantidadObjetivo();
            int pct = objetivo > 0 ? (int) Math.min(100, Math.round(cubierto / objetivo * 100)) : 0;
            Map<String, Object> m = Json.obj();
            m.put("id", n.getId());
            m.put("alimentoId", a.getId());
            m.put("nombre", a.getNombre());
            m.put("unidad", a.getUnidad());
            m.put("icono", a.getIcono());
            m.put("categoria", a.getCategoria());
            m.put("urgente", n.isUrgente());
            m.put("objetivo", objetivo);
            m.put("cubierto", cubierto);
            m.put("pct", pct);
            m.put("completa", cubierto >= objetivo);
            salida.add(m);
        }
        salida.sort(Comparator
                .comparing((Map<String, Object> x) -> !(Boolean) x.get("urgente"))
                .thenComparing(x -> (String) x.get("nombre")));
        return salida;
    }

    @GetMapping("/estadisticas")
    public Map<String, Object> estadisticas() {
        double kg = 0;
        for (Lote l : loteRepo.findAll()) {
            kg += l.getCantidadInicial();
        }
        Map<String, Object> m = Json.obj();
        m.put("kgMes", kg);
        m.put("merenderos", merenderoRepo.countByActivoTrue());
        m.put("entregas", entregaRepo.count());
        return m;
    }

    @GetMapping("/health")
    public String health() {
        return "ok";
    }
}
