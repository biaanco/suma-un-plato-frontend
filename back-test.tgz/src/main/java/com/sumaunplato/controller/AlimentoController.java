package com.sumaunplato.controller;

import com.sumaunplato.model.Alimento;
import com.sumaunplato.model.Merendero;
import com.sumaunplato.model.PlanillaNecesidad;
import com.sumaunplato.repository.AlimentoRepository;
import com.sumaunplato.repository.MerenderoRepository;
import com.sumaunplato.repository.PlanillaNecesidadRepository;
import com.sumaunplato.util.Json;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Tag(name = "Alimentos", description = "CRUD del catalogo de alimentos")
@RestController
@RequestMapping("/api/alimentos")
public class AlimentoController {

    private final AlimentoRepository alimentoRepo;
    private final MerenderoRepository merenderoRepo;
    private final PlanillaNecesidadRepository planillaRepo;

    public AlimentoController(AlimentoRepository alimentoRepo, MerenderoRepository merenderoRepo,
                              PlanillaNecesidadRepository planillaRepo) {
        this.alimentoRepo = alimentoRepo;
        this.merenderoRepo = merenderoRepo;
        this.planillaRepo = planillaRepo;
    }

    @Operation(summary = "Listar alimentos activos del catalogo")
    @GetMapping
    public List<Alimento> listar() {
        return alimentoRepo.findByActivoTrueOrderByNombreAsc();
    }

    @Operation(summary = "Listar productos que pidieron los merenderos con \"Otros\" y falta revisar")
    @GetMapping("/sugeridos")
    public List<Map<String, Object>> sugeridos() {
        List<Map<String, Object>> salida = new ArrayList<>();
        for (Alimento a : alimentoRepo.findByPendienteTrueOrderByIdAsc()) {
            Map<String, Object> m = Json.obj();
            m.put("id", a.getId());
            m.put("nombre", a.getNombre());
            m.put("unidad", a.getUnidad());
            m.put("categoria", a.getCategoria());
            m.put("icono", a.getIcono());
            m.put("merendero", a.getSugeridoPorMerenderoId() != null
                    ? merenderoRepo.findById(a.getSugeridoPorMerenderoId()).map(Merendero::getNombre).orElse("")
                    : "");
            double total = 0;
            for (PlanillaNecesidad p : planillaRepo.findByAlimentoId(a.getId())) {
                total += p.getCantidad();
            }
            m.put("cantidad", total);
            salida.add(m);
        }
        return salida;
    }

    @Operation(summary = "Aprobar un producto sugerido (con los datos editados) y sumarlo al catalogo")
    @PostMapping("/{id}/aprobar")
    public ResponseEntity<Map<String, Object>> aprobar(@PathVariable Long id, @RequestBody Alimento datos) {
        Alimento a = alimentoRepo.findById(id).orElse(null);
        if (a == null || !a.isPendiente()) {
            return ResponseEntity.notFound().build();
        }
        if (datos.getNombre() == null || datos.getNombre().isBlank()) {
            return ResponseEntity.badRequest().body(Json.error("El producto necesita un nombre"));
        }
        a.setNombre(datos.getNombre().trim());
        a.setUnidad(datos.getUnidad());
        a.setCategoria(datos.getCategoria());
        a.setIcono(datos.getIcono());
        a.setPendiente(false);
        a.setActivo(true);
        alimentoRepo.save(a);
        return ResponseEntity.ok(Json.ok(a.getNombre() + " ya está en el catálogo"));
    }

    @Operation(summary = "Reemplazar un producto sugerido por uno que ya existe en el catalogo")
    @PostMapping("/{id}/unir")
    public ResponseEntity<Map<String, Object>> unir(@PathVariable Long id, @RequestBody Map<String, Object> datos) {
        Alimento a = alimentoRepo.findById(id).orElse(null);
        Object destinoId = datos.get("alimentoId");
        Alimento destino = destinoId != null ? alimentoRepo.findById(Long.valueOf(destinoId.toString())).orElse(null) : null;
        if (a == null || !a.isPendiente() || destino == null || destino.isPendiente()) {
            return ResponseEntity.badRequest().body(Json.error("Elegí un producto del catálogo"));
        }
        for (PlanillaNecesidad p : planillaRepo.findByAlimentoId(a.getId())) {
            p.setAlimentoId(destino.getId());
            planillaRepo.save(p);
        }
        alimentoRepo.delete(a);
        return ResponseEntity.ok(Json.ok("Pedido pasado a " + destino.getNombre()));
    }

    @Operation(summary = "Obtener un alimento por su id")
    @GetMapping("/{id}")
    public ResponseEntity<Alimento> obtener(@PathVariable Long id) {
        return alimentoRepo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear un alimento nuevo")
    @PostMapping
    public Alimento crear(@RequestBody Alimento alimento) {
        alimento.setId(null);
        alimento.setActivo(true);
        return alimentoRepo.save(alimento);
    }

    @Operation(summary = "Actualizar un alimento existente")
    @PutMapping("/{id}")
    public ResponseEntity<Alimento> actualizar(@PathVariable Long id, @RequestBody Alimento datos) {
        return alimentoRepo.findById(id).map(alimento -> {
            alimento.setNombre(datos.getNombre());
            alimento.setCategoria(datos.getCategoria());
            alimento.setUnidad(datos.getUnidad());
            alimento.setIcono(datos.getIcono());
            return ResponseEntity.ok(alimentoRepo.save(alimento));
        }).orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Eliminar un alimento por su id")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (!alimentoRepo.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        alimentoRepo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
