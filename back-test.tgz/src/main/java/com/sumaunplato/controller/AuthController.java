package com.sumaunplato.controller;

import com.sumaunplato.dto.ForgotPasswordRequest;
import com.sumaunplato.dto.LoginRequest;
import com.sumaunplato.dto.RegistroRequest;
import com.sumaunplato.dto.ResetPasswordRequest;
import com.sumaunplato.dto.TokenResponse;
import com.sumaunplato.model.Usuario;
import com.sumaunplato.repository.UsuarioRepository;
import com.sumaunplato.seguridad.JwtService;
import com.sumaunplato.util.Json;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Tag(name = "Autenticacion", description = "Registro, inicio de sesion y recuperacion de contrasena")
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UsuarioRepository usuarioRepo;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthController(UsuarioRepository usuarioRepo, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.usuarioRepo = usuarioRepo;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    @Operation(summary = "Iniciar sesion con email y contrasena")
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest datos) {
        String email = datos.getEmail() != null ? datos.getEmail().trim() : "";
        String password = datos.getPassword() != null ? datos.getPassword() : "";
        Optional<Usuario> encontrado = usuarioRepo.findByEmail(email);
        if (encontrado.isEmpty() || !encontrado.get().isActivo()
                || !passwordEncoder.matches(password, encontrado.get().getPasswordHash())) {
            return ResponseEntity.status(401).body(Json.error("Email o contrasena incorrectos"));
        }
        return ResponseEntity.ok(usuarioPublico(encontrado.get()));
    }

    @Operation(summary = "Registrar un donante nuevo")
    @PostMapping("/registro")
    public ResponseEntity<Map<String, Object>> registro(@RequestBody RegistroRequest datos) {
        String nombre = datos.getNombre() != null ? datos.getNombre().trim() : "";
        String apellido = datos.getApellido() != null ? datos.getApellido().trim() : "";
        String dni = datos.getDni() != null ? datos.getDni().replaceAll("\\D", "") : "";
        String email = datos.getEmail() != null ? datos.getEmail().trim() : "";
        String password = datos.getPassword() != null ? datos.getPassword() : "";
        String tipo = datos.getTipoDonante() != null ? datos.getTipoDonante() : "persona";

        if (nombre.isEmpty() || apellido.isEmpty() || email.isEmpty() || password.length() < 6) {
            return ResponseEntity.badRequest().body(Json.error("Completa nombre, apellido, email y una contrasena de 6 o mas caracteres"));
        }
        if (!dni.matches("\\d{7,8}")) {
            return ResponseEntity.badRequest().body(Json.error("El DNI debe tener 7 u 8 numeros"));
        }
        if (usuarioRepo.existsByEmail(email)) {
            return ResponseEntity.badRequest().body(Json.error("Ya existe una cuenta con ese email"));
        }
        if (usuarioRepo.existsByDni(dni)) {
            return ResponseEntity.badRequest().body(Json.error("Ya existe una cuenta con ese DNI"));
        }

        Usuario u = new Usuario();
        u.setNombre(nombre);
        u.setApellido(apellido);
        u.setDni(dni);
        u.setEmail(email);
        u.setTelefono(datos.getTelefono() != null ? datos.getTelefono() : "");
        u.setPasswordHash(passwordEncoder.encode(password));
        u.setRol("donante");
        u.setTipoDonante(tipo);
        u.setActivo(true);
        usuarioRepo.save(u);
        return ResponseEntity.ok(usuarioPublico(u));
    }

    @Operation(summary = "Pedir un token para recuperar la contrasena")
    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody ForgotPasswordRequest datos) {
        String email = datos.getEmail() != null ? datos.getEmail().trim() : "";
        Optional<Usuario> encontrado = usuarioRepo.findByEmail(email);
        if (encontrado.isEmpty()) {
            return ResponseEntity.status(404).body(Json.error("No existe una cuenta con ese email"));
        }
        Usuario usuario = encontrado.get();
        String token = UUID.randomUUID().toString();
        usuario.setResetToken(token);
        usuario.setResetTokenExpiry(LocalDateTime.now().plusHours(1));
        usuarioRepo.save(usuario);
        return ResponseEntity.ok(new TokenResponse(token));
    }

    @Operation(summary = "Cambiar la contrasena usando el token de recuperacion")
    @PostMapping("/reset-password")
    public ResponseEntity<Map<String, Object>> resetPassword(@RequestBody ResetPasswordRequest datos) {
        String token = datos.getToken() != null ? datos.getToken().trim() : "";
        String nueva = datos.getNewPassword() != null ? datos.getNewPassword() : "";
        if (nueva.length() < 6) {
            return ResponseEntity.badRequest().body(Json.error("La nueva contrasena necesita al menos 6 caracteres"));
        }
        Optional<Usuario> encontrado = usuarioRepo.findByResetToken(token);
        if (encontrado.isEmpty() || encontrado.get().getResetTokenExpiry() == null
                || encontrado.get().getResetTokenExpiry().isBefore(LocalDateTime.now())) {
            return ResponseEntity.badRequest().body(Json.error("El token es invalido o ya vencio"));
        }
        Usuario usuario = encontrado.get();
        usuario.setPasswordHash(passwordEncoder.encode(nueva));
        usuario.setResetToken(null);
        usuario.setResetTokenExpiry(null);
        usuarioRepo.save(usuario);
        return ResponseEntity.ok(Json.ok("Contrasena actualizada. Ya podes ingresar con la nueva."));
    }

    private Map<String, Object> usuarioPublico(Usuario u) {
        Map<String, Object> m = Json.obj();
        m.put("id", u.getId());
        m.put("nombre", u.getNombre());
        m.put("email", u.getEmail());
        m.put("rol", u.getRol());
        m.put("token", jwtService.generarToken(u.getEmail(), u.getRol()));
        return m;
    }
}
