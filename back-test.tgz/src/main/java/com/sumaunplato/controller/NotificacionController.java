package com.sumaunplato.controller;

import com.sumaunplato.model.Notificacion;
import com.sumaunplato.repository.NotificacionRepository;
import com.sumaunplato.util.Json;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Tag(name = "Notificaciones", description = "Avisos de agradecimiento para los donantes")
@RestController
@RequestMapping("/api/notificaciones")
public class NotificacionController {

    private final NotificacionRepository notificacionRepo;

    public NotificacionController(NotificacionRepository notificacionRepo) {
        this.notificacionRepo = notificacionRepo;
    }

    @GetMapping("/usuario/{usuarioId}")
    public List<Map<String, Object>> porUsuario(@PathVariable Long usuarioId) {
        List<Notificacion> lista = notificacionRepo.findByUsuarioIdOrderByCreadoEnDesc(usuarioId);
        List<Map<String, Object>> salida = new ArrayList<>();
        for (Notificacion n : lista) {
            Map<String, Object> m = Json.obj();
            m.put("id", n.getId());
            m.put("mensaje", n.getMensaje());
            m.put("leido", n.isLeido());
            m.put("creadoEn", n.getCreadoEn());
            salida.add(m);
        }
        for (Notificacion n : notificacionRepo.findByUsuarioIdAndLeidoFalse(usuarioId)) {
            n.setLeido(true);
            notificacionRepo.save(n);
        }
        return salida;
    }
}
