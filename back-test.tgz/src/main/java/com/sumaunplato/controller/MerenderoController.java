package com.sumaunplato.controller;

import com.sumaunplato.model.Alimento;
import com.sumaunplato.model.Entrega;
import com.sumaunplato.model.EntregaItem;
import com.sumaunplato.model.Merendero;
import com.sumaunplato.model.Notificacion;
import com.sumaunplato.model.PlanillaNecesidad;
import com.sumaunplato.model.Usuario;
import com.sumaunplato.repository.AlimentoRepository;
import com.sumaunplato.repository.EntregaItemRepository;
import com.sumaunplato.repository.EntregaRepository;
import com.sumaunplato.repository.MerenderoRepository;
import com.sumaunplato.repository.NotificacionRepository;
import com.sumaunplato.repository.PlanillaNecesidadRepository;
import com.sumaunplato.repository.UsuarioRepository;
import com.sumaunplato.service.DepositoService;
import com.sumaunplato.util.Json;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Tag(name = "Merenderos", description = "Alta, edicion y baja de merenderos, y sus planillas de necesidades")
@RestController
@RequestMapping("/api/merenderos")
public class MerenderoController {

    private final MerenderoRepository merenderoRepo;
    private final UsuarioRepository usuarioRepo;
    private final PlanillaNecesidadRepository planillaRepo;
    private final AlimentoRepository alimentoRepo;
    private final EntregaRepository entregaRepo;
    private final EntregaItemRepository entregaItemRepo;
    private final DepositoService deposito;
    private final NotificacionRepository notificacionRepo;
    private final PasswordEncoder passwordEncoder;

    public MerenderoController(MerenderoRepository merenderoRepo, UsuarioRepository usuarioRepo,
                               PlanillaNecesidadRepository planillaRepo, AlimentoRepository alimentoRepo,
                               EntregaRepository entregaRepo, EntregaItemRepository entregaItemRepo,
                               DepositoService deposito, NotificacionRepository notificacionRepo,
                               PasswordEncoder passwordEncoder) {
        this.merenderoRepo = merenderoRepo;
        this.usuarioRepo = usuarioRepo;
        this.planillaRepo = planillaRepo;
        this.alimentoRepo = alimentoRepo;
        this.entregaRepo = entregaRepo;
        this.entregaItemRepo = entregaItemRepo;
        this.deposito = deposito;
        this.notificacionRepo = notificacionRepo;
        this.passwordEncoder = passwordEncoder;
    }

    @Operation(summary = "Listar todos los merenderos")
    @GetMapping
    public List<Map<String, Object>> listar() {
        List<Map<String, Object>> salida = new ArrayList<>();
        for (Merendero m : merenderoRepo.findAllByOrderByActivoDescNombreAsc()) {
            Usuario u = m.getUsuarioId() != null ? usuarioRepo.findById(m.getUsuarioId()).orElse(null) : null;
            Map<String, Object> x = Json.obj();
            x.put("id", m.getId());
            x.put("nombre", m.getNombre());
            x.put("direccion", m.getDireccion());
            x.put("referente", m.getReferente());
            x.put("telefono", m.getTelefono());
            x.put("capacidad", m.getCapacidad());
            x.put("horarios", m.getHorarios());
            x.put("activo", m.isActivo());
            x.put("email", u != null ? u.getEmail() : "");
            salida.add(x);
        }
        return salida;
    }

    @Operation(summary = "Crear un merendero y su cuenta de acceso")
    @PostMapping
    public ResponseEntity<Map<String, Object>> crear(@RequestBody Map<String, Object> datos) {
        String nombre = texto(datos, "nombre");
        String email = texto(datos, "email");
        String password = texto(datos, "password");
        if (nombre.isEmpty() || email.isEmpty() || password.length() < 6) {
            return ResponseEntity.badRequest().body(Json.error("Completá nombre, email y contraseña de 6 o más caracteres"));
        }
        if (usuarioRepo.existsByEmail(email)) {
            return ResponseEntity.badRequest().body(Json.error("Ya existe un usuario con ese email"));
        }
        Usuario u = new Usuario();
        u.setNombre(nombre);
        u.setEmail(email);
        u.setTelefono(texto(datos, "telefono"));
        u.setPasswordHash(passwordEncoder.encode(password));
        u.setRol("merendero");
        u.setActivo(true);
        usuarioRepo.save(u);

        Merendero m = new Merendero();
        m.setUsuarioId(u.getId());
        m.setNombre(nombre);
        m.setDireccion(texto(datos, "direccion"));
        m.setReferente(texto(datos, "referente"));
        m.setTelefono(texto(datos, "telefono"));
        m.setCapacidad(entero(datos, "capacidad"));
        m.setHorarios(texto(datos, "horarios"));
        m.setActivo(true);
        merenderoRepo.save(m);
        return ResponseEntity.ok(Json.ok("Merendero creado"));
    }

    @Operation(summary = "Editar los datos de un merendero")
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> editar(@PathVariable Long id, @RequestBody Map<String, Object> datos) {
        Merendero m = merenderoRepo.findById(id).orElse(null);
        if (m == null) {
            return ResponseEntity.notFound().build();
        }
        m.setNombre(texto(datos, "nombre"));
        m.setDireccion(texto(datos, "direccion"));
        m.setReferente(texto(datos, "referente"));
        m.setTelefono(texto(datos, "telefono"));
        m.setCapacidad(entero(datos, "capacidad"));
        m.setHorarios(texto(datos, "horarios"));
        merenderoRepo.save(m);
        return ResponseEntity.ok(Json.ok("Merendero actualizado"));
    }

    @Operation(summary = "Activar o desactivar un merendero")
    @PostMapping("/{id}/toggle")
    public ResponseEntity<Map<String, Object>> alternar(@PathVariable Long id) {
        Merendero m = merenderoRepo.findById(id).orElse(null);
        if (m == null) {
            return ResponseEntity.notFound().build();
        }
        boolean nuevo = !m.isActivo();
        m.setActivo(nuevo);
        merenderoRepo.save(m);
        if (m.getUsuarioId() != null) {
            usuarioRepo.findById(m.getUsuarioId()).ifPresent(u -> {
                u.setActivo(nuevo);
                usuarioRepo.save(u);
            });
        }
        return ResponseEntity.ok(Json.ok(nuevo ? "Merendero reactivado" : "Merendero desactivado"));
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<Map<String, Object>> porUsuario(@PathVariable Long usuarioId) {
        Merendero m = merenderoRepo.findByUsuarioIdAndActivoTrue(usuarioId).orElse(null);
        if (m == null) {
            return ResponseEntity.notFound().build();
        }
        Map<String, Object> x = Json.obj();
        x.put("id", m.getId());
        x.put("nombre", m.getNombre());
        x.put("direccion", m.getDireccion());
        x.put("horarios", m.getHorarios());
        return ResponseEntity.ok(x);
    }

    @GetMapping("/{id}/planilla")
    public List<Map<String, Object>> planilla(@PathVariable Long id) {
        List<Map<String, Object>> salida = new ArrayList<>();
        for (PlanillaNecesidad p : planillaRepo.findByMerenderoId(id)) {
            Alimento a = alimentoRepo.findById(p.getAlimentoId()).orElse(null);
            Map<String, Object> m = Json.obj();
            m.put("id", p.getId());
            m.put("nombre", a != null ? a.getNombre() : "");
            m.put("icono", a != null ? a.getIcono() : "bag");
            m.put("cantidad", p.getCantidad());
            m.put("unidad", a != null ? a.getUnidad() : "");
            m.put("urgencia", p.getUrgencia());
            m.put("estado", p.getEstado());
            m.put("pendiente", a != null && a.isPendiente());
            salida.add(m);
        }
        return salida;
    }

    @PostMapping("/{id}/planilla")
    public ResponseEntity<Map<String, Object>> agregarPlanilla(@PathVariable Long id, @RequestBody Map<String, Object> datos) {
        double cantidad = Double.parseDouble(datos.get("cantidad").toString());
        String urgencia = texto(datos, "urgencia");
        if (urgencia.isEmpty()) {
            urgencia = "media";
        }
        if (cantidad <= 0) {
            return ResponseEntity.badRequest().body(Json.error("La cantidad debe ser mayor a 0"));
        }
        String otroNombre = texto(datos, "otroNombre");
        Long alimentoId;
        if (!otroNombre.isEmpty()) {
            alimentoId = sugerirAlimento(id, otroNombre, texto(datos, "otraUnidad"));
        } else if (datos.get("alimentoId") != null) {
            alimentoId = Long.valueOf(datos.get("alimentoId").toString());
        } else {
            return ResponseEntity.badRequest().body(Json.error("Elegí un producto o escribí cuál necesitás"));
        }
        PlanillaNecesidad p = new PlanillaNecesidad();
        p.setMerenderoId(id);
        p.setAlimentoId(alimentoId);
        p.setCantidad(cantidad);
        p.setUrgencia(urgencia);
        p.setEstado("pendiente");
        planillaRepo.save(p);
        return ResponseEntity.ok(Json.ok("Necesidad agregada"));
    }

    // Crea un alimento fuera del catalogo (pendiente de revision) y avisa a los admins
    private Long sugerirAlimento(Long merenderoId, String nombre, String unidad) {
        Alimento a = new Alimento();
        a.setNombre(nombre);
        a.setUnidad(unidad.isEmpty() ? "u" : unidad);
        a.setCategoria("no_perecedero");
        a.setIcono("bag");
        a.setActivo(false);
        a.setPendiente(true);
        a.setSugeridoPorMerenderoId(merenderoId);
        alimentoRepo.save(a);

        String merendero = merenderoRepo.findById(merenderoId).map(Merendero::getNombre).orElse("Un merendero");
        for (Usuario admin : usuarioRepo.findByRol("admin")) {
            Notificacion n = new Notificacion();
            n.setUsuarioId(admin.getId());
            n.setMensaje(merendero + " pidió un producto que no está en el catálogo: " + nombre + ". Revisalo en Productos sugeridos.");
            notificacionRepo.save(n);
        }
        return a.getId();
    }

    @DeleteMapping("/planilla/{planillaId}")
    public ResponseEntity<Map<String, Object>> quitarPlanilla(@PathVariable Long planillaId) {
        planillaRepo.deleteById(planillaId);
        return ResponseEntity.ok(Json.ok("Necesidad quitada"));
    }

    @GetMapping("/{id}/entregas")
    public List<Map<String, Object>> entregas(@PathVariable Long id) {
        List<Map<String, Object>> salida = new ArrayList<>();
        for (Entrega e : entregaRepo.findByMerenderoIdAndEstadoOrderByCreadoEnDesc(id, "preparada")) {
            Map<String, Object> m = Json.obj();
            m.put("id", e.getId());
            m.put("creadoEn", e.getCreadoEn());
            List<Map<String, Object>> items = new ArrayList<>();
            for (EntregaItem ei : entregaItemRepo.findByEntregaId(e.getId())) {
                Alimento a = alimentoRepo.findById(ei.getAlimentoId()).orElse(null);
                Map<String, Object> mi = Json.obj();
                mi.put("nombre", a != null ? a.getNombre() : "");
                mi.put("icono", a != null ? a.getIcono() : "bag");
                mi.put("cantidad", ei.getCantidad());
                mi.put("unidad", a != null ? a.getUnidad() : "");
                items.add(mi);
            }
            m.put("items", items);
            salida.add(m);
        }
        return salida;
    }

    @PostMapping("/entrega/recibir")
    public ResponseEntity<Map<String, Object>> recibir(@RequestBody Map<String, Object> datos) {
        Long entregaId = Long.valueOf(datos.get("entregaId").toString());
        Long merenderoId = Long.valueOf(datos.get("merenderoId").toString());
        try {
            deposito.recibirEntrega(entregaId, merenderoId);
            return ResponseEntity.ok(Json.ok("Recepción confirmada. Gracias por cerrar el círculo."));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Json.error("No se pudo confirmar la recepción"));
        }
    }

    private String texto(Map<String, Object> datos, String clave) {
        Object v = datos.get(clave);
        return v != null ? v.toString().trim() : "";
    }

    private Integer entero(Map<String, Object> datos, String clave) {
        Object v = datos.get(clave);
        if (v == null || v.toString().isEmpty()) {
            return null;
        }
        try {
            return Integer.parseInt(v.toString().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
