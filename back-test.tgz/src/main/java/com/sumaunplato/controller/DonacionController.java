package com.sumaunplato.controller;

import com.sumaunplato.model.Alimento;
import com.sumaunplato.model.Donacion;
import com.sumaunplato.model.DonacionItem;
import com.sumaunplato.repository.AlimentoRepository;
import com.sumaunplato.repository.DonacionItemRepository;
import com.sumaunplato.repository.DonacionRepository;
import com.sumaunplato.util.Json;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Tag(name = "Donaciones", description = "Creacion y seguimiento de donaciones")
@RestController
@RequestMapping("/api/donaciones")
public class DonacionController {

    private final DonacionRepository donacionRepo;
    private final DonacionItemRepository itemRepo;
    private final AlimentoRepository alimentoRepo;

    public DonacionController(DonacionRepository donacionRepo, DonacionItemRepository itemRepo,
                              AlimentoRepository alimentoRepo) {
        this.donacionRepo = donacionRepo;
        this.itemRepo = itemRepo;
        this.alimentoRepo = alimentoRepo;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> crear(@RequestBody Map<String, Object> datos) {
        Long donanteId = Long.valueOf(datos.get("donanteId").toString());
        String nota = datos.get("nota") != null ? datos.get("nota").toString() : null;
        List<Map<String, Object>> items = (List<Map<String, Object>>) datos.get("items");

        if (items == null || items.isEmpty()) {
            return ResponseEntity.badRequest().body(Json.error("La donación está vacía"));
        }

        Donacion d = new Donacion();
        d.setDonanteId(donanteId);
        d.setEstado("registrada");
        d.setNota(nota);
        donacionRepo.save(d);

        for (Map<String, Object> it : items) {
            Long alimentoId = Long.valueOf(it.get("alimentoId").toString());
            double cantidad = Double.parseDouble(it.get("cantidad").toString());
            if (cantidad <= 0) {
                continue;
            }
            Alimento a = alimentoRepo.findById(alimentoId).orElse(null);
            DonacionItem item = new DonacionItem();
            item.setDonacionId(d.getId());
            item.setAlimentoId(alimentoId);
            item.setCantidad(cantidad);
            item.setUnidad(a != null ? a.getUnidad() : "u");
            itemRepo.save(item);
        }
        return ResponseEntity.ok(armarDonacion(d));
    }

    @GetMapping("/usuario/{donanteId}")
    public List<Map<String, Object>> porUsuario(@PathVariable Long donanteId) {
        List<Map<String, Object>> salida = new ArrayList<>();
        for (Donacion d : donacionRepo.findByDonanteIdOrderByCreadoEnDesc(donanteId)) {
            salida.add(armarDonacion(d));
        }
        return salida;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> uno(@PathVariable Long id) {
        return donacionRepo.findById(id)
                .map(d -> ResponseEntity.ok(armarDonacion(d)))
                .orElse(ResponseEntity.notFound().build());
    }

    private Map<String, Object> armarDonacion(Donacion d) {
        Map<String, Object> m = Json.obj();
        m.put("id", d.getId());
        m.put("donanteId", d.getDonanteId());
        m.put("estado", d.getEstado());
        m.put("nota", d.getNota());
        m.put("creadoEn", d.getCreadoEn());

        List<Map<String, Object>> items = new ArrayList<>();
        for (DonacionItem it : itemRepo.findByDonacionId(d.getId())) {
            Alimento a = alimentoRepo.findById(it.getAlimentoId()).orElse(null);
            Map<String, Object> mi = Json.obj();
            mi.put("alimentoId", it.getAlimentoId());
            mi.put("nombre", a != null ? a.getNombre() : "");
            mi.put("icono", a != null ? a.getIcono() : "bag");
            mi.put("cantidad", it.getCantidad());
            mi.put("unidad", it.getUnidad());
            items.add(mi);
        }
        m.put("items", items);
        return m;
    }
}
