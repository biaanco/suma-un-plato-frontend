package com.sumaunplato.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI sumaUnPlatoOpenAPI() {
        return new OpenAPI().info(new Info()
                .title("Suma un plato API")
                .version("1.0.0")
                .description("API del sistema de gestion de donaciones de alimentos para comedores y merenderos de Laboulaye."));
    }
}
