package com.sumaunplato.config;

import com.sumaunplato.model.Alimento;
import com.sumaunplato.model.Donacion;
import com.sumaunplato.model.DonacionItem;
import com.sumaunplato.model.Lote;
import com.sumaunplato.model.Merendero;
import com.sumaunplato.model.Movimiento;
import com.sumaunplato.model.NecesidadPublicada;
import com.sumaunplato.model.Notificacion;
import com.sumaunplato.model.PlanillaNecesidad;
import com.sumaunplato.model.Usuario;
import com.sumaunplato.repository.AlimentoRepository;
import com.sumaunplato.repository.DonacionItemRepository;
import com.sumaunplato.repository.DonacionRepository;
import com.sumaunplato.repository.LoteRepository;
import com.sumaunplato.repository.MerenderoRepository;
import com.sumaunplato.repository.MovimientoRepository;
import com.sumaunplato.repository.NecesidadPublicadaRepository;
import com.sumaunplato.repository.NotificacionRepository;
import com.sumaunplato.repository.PlanillaNecesidadRepository;
import com.sumaunplato.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepo;
    private final MerenderoRepository merenderoRepo;
    private final AlimentoRepository alimentoRepo;
    private final NecesidadPublicadaRepository necesidadRepo;
    private final PlanillaNecesidadRepository planillaRepo;
    private final DonacionRepository donacionRepo;
    private final DonacionItemRepository donacionItemRepo;
    private final LoteRepository loteRepo;
    private final MovimientoRepository movimientoRepo;
    private final NotificacionRepository notificacionRepo;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UsuarioRepository usuarioRepo, MerenderoRepository merenderoRepo,
                           AlimentoRepository alimentoRepo, NecesidadPublicadaRepository necesidadRepo,
                           PlanillaNecesidadRepository planillaRepo, DonacionRepository donacionRepo,
                           DonacionItemRepository donacionItemRepo, LoteRepository loteRepo,
                           MovimientoRepository movimientoRepo, NotificacionRepository notificacionRepo,
                           PasswordEncoder passwordEncoder) {
        this.usuarioRepo = usuarioRepo;
        this.merenderoRepo = merenderoRepo;
        this.alimentoRepo = alimentoRepo;
        this.necesidadRepo = necesidadRepo;
        this.planillaRepo = planillaRepo;
        this.donacionRepo = donacionRepo;
        this.donacionItemRepo = donacionItemRepo;
        this.loteRepo = loteRepo;
        this.movimientoRepo = movimientoRepo;
        this.notificacionRepo = notificacionRepo;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (usuarioRepo.count() > 0) {
            return;
        }

        Usuario admin = crearUsuario("Fabian Coordinador", "admin@sumaunplato.org", "3385-000000", "admin123", "admin", null);
        Usuario maria = crearUsuario("Maria Vecina", "maria@example.com", "3385-111111", "maria123", "donante", "persona");
        crearUsuario("Panaderia La Espiga", "espiga@example.com", "3385-222222", "maria123", "donante", "comercio");
        Usuario um1 = crearUsuario("Merendero Los Angelitos", "angelitos@example.com", "3385-333333", "merendero123", "merendero", null);
        Usuario um2 = crearUsuario("Merendero La Sonrisa", "sonrisa@example.com", "3385-444444", "merendero123", "merendero", null);

        Merendero m1 = crearMerendero(um1.getId(), "Merendero Los Angelitos", "Barrio Norte 250, Laboulaye", "Rosa Gomez", "3385-333333", 60, "Lun a Vie 16:00-18:00");
        Merendero m2 = crearMerendero(um2.getId(), "Merendero La Sonrisa", "Bo San Martin 1200, Laboulaye", "Carlos Diaz", "3385-444444", 45, "Mar y Jue 17:00-19:00");

        Map<String, Alimento> a = new HashMap<>();
        a.put("arroz", crearAlimento("Arroz", "no_perecedero", "kg", "rice"));
        a.put("fideos", crearAlimento("Fideos", "no_perecedero", "paq", "pasta"));
        a.put("harina", crearAlimento("Harina", "no_perecedero", "kg", "flour"));
        a.put("aceite", crearAlimento("Aceite", "no_perecedero", "L", "oil"));
        a.put("azucar", crearAlimento("Azucar", "no_perecedero", "kg", "sugar"));
        a.put("yerba", crearAlimento("Yerba", "no_perecedero", "kg", "leaf"));
        a.put("lentejas", crearAlimento("Lentejas", "no_perecedero", "kg", "bean"));
        a.put("tomate", crearAlimento("Pure de tomate", "no_perecedero", "u", "can"));
        a.put("leche", crearAlimento("Leche larga vida", "no_perecedero", "u", "milk"));
        a.put("verduras", crearAlimento("Verduras", "perecedero", "kg", "carrot"));
        a.put("frutas", crearAlimento("Frutas", "perecedero", "kg", "apple"));
        a.put("pan", crearAlimento("Pan", "perecedero", "kg", "bread"));
        a.put("yogur", crearAlimento("Yogur", "perecedero", "u", "milk"));
        a.put("huevos", crearAlimento("Huevos", "perecedero", "u", "egg"));
        a.put("queso", crearAlimento("Queso", "perecedero", "kg", "cheese"));

        crearNecesidad(a.get("arroz").getId(), 30, true);
        crearNecesidad(a.get("leche").getId(), 40, true);
        crearNecesidad(a.get("verduras").getId(), 25, false);
        crearNecesidad(a.get("fideos").getId(), 20, false);
        crearNecesidad(a.get("aceite").getId(), 15, false);
        crearNecesidad(a.get("lentejas").getId(), 12, true);

        crearPlanilla(m1.getId(), a.get("arroz").getId(), 15, "alta");
        crearPlanilla(m1.getId(), a.get("leche").getId(), 20, "alta");
        crearPlanilla(m1.getId(), a.get("verduras").getId(), 12, "media");
        crearPlanilla(m1.getId(), a.get("fideos").getId(), 10, "baja");
        crearPlanilla(m2.getId(), a.get("arroz").getId(), 15, "alta");
        crearPlanilla(m2.getId(), a.get("leche").getId(), 20, "media");
        crearPlanilla(m2.getId(), a.get("lentejas").getId(), 12, "alta");
        crearPlanilla(m2.getId(), a.get("aceite").getId(), 15, "media");

        Donacion d1 = crearDonacion(maria.getId(), "ingresada");
        crearItem(d1.getId(), a.get("arroz").getId(), 5, "kg");
        crearItem(d1.getId(), a.get("leche").getId(), 6, "u");
        crearItem(d1.getId(), a.get("yogur").getId(), 12, "u");

        Donacion d3 = crearDonacion(maria.getId(), "registrada");
        crearItem(d3.getId(), a.get("fideos").getId(), 4, "paq");
        crearItem(d3.getId(), a.get("leche").getId(), 6, "u");
        crearItem(d3.getId(), a.get("frutas").getId(), 5, "kg");

        crearLote(a.get("arroz").getId(), 5, d1.getId(), null, admin.getId());
        crearLote(a.get("leche").getId(), 6, d1.getId(), LocalDate.now().plusDays(80), admin.getId());
        crearLote(a.get("yogur").getId(), 12, d1.getId(), LocalDate.now().plusDays(2), admin.getId());
        crearLote(a.get("pan").getId(), 8, null, LocalDate.now().plusDays(1), admin.getId());
        crearLote(a.get("harina").getId(), 10, null, null, admin.getId());
        crearLote(a.get("verduras").getId(), 14, null, LocalDate.now().plusDays(8), admin.getId());
        crearLote(a.get("frutas").getId(), 9, null, LocalDate.now().plusDays(10), admin.getId());
        crearLote(a.get("huevos").getId(), 30, null, LocalDate.now().plusDays(25), admin.getId());
        crearLote(a.get("aceite").getId(), 6, null, null, admin.getId());

        Notificacion n = new Notificacion();
        n.setUsuarioId(maria.getId());
        n.setMensaje("Gracias Maria! Tu leche ya llego a un merendero de la red.");
        notificacionRepo.save(n);
    }

    private Usuario crearUsuario(String nombre, String email, String tel, String pass, String rol, String tipo) {
        Usuario u = new Usuario();
        u.setNombre(nombre);
        u.setEmail(email);
        u.setTelefono(tel);
        u.setPasswordHash(passwordEncoder.encode(pass));
        u.setRol(rol);
        u.setTipoDonante(tipo);
        u.setActivo(true);
        return usuarioRepo.save(u);
    }

    private Merendero crearMerendero(Long usuarioId, String nombre, String dir, String ref, String tel, int cap, String hor) {
        Merendero m = new Merendero();
        m.setUsuarioId(usuarioId);
        m.setNombre(nombre);
        m.setDireccion(dir);
        m.setReferente(ref);
        m.setTelefono(tel);
        m.setCapacidad(cap);
        m.setHorarios(hor);
        m.setActivo(true);
        return merenderoRepo.save(m);
    }

    private Alimento crearAlimento(String nombre, String cat, String unidad, String icono) {
        Alimento al = new Alimento();
        al.setNombre(nombre);
        al.setCategoria(cat);
        al.setUnidad(unidad);
        al.setIcono(icono);
        al.setActivo(true);
        return alimentoRepo.save(al);
    }

    private void crearNecesidad(Long alimentoId, double objetivo, boolean urgente) {
        NecesidadPublicada n = new NecesidadPublicada();
        n.setAlimentoId(alimentoId);
        n.setCantidadObjetivo(objetivo);
        n.setUrgente(urgente);
        n.setActiva(true);
        necesidadRepo.save(n);
    }

    private void crearPlanilla(Long merenderoId, Long alimentoId, double cantidad, String urgencia) {
        PlanillaNecesidad p = new PlanillaNecesidad();
        p.setMerenderoId(merenderoId);
        p.setAlimentoId(alimentoId);
        p.setCantidad(cantidad);
        p.setUrgencia(urgencia);
        p.setEstado("pendiente");
        planillaRepo.save(p);
    }

    private Donacion crearDonacion(Long donanteId, String estado) {
        Donacion d = new Donacion();
        d.setDonanteId(donanteId);
        d.setEstado(estado);
        return donacionRepo.save(d);
    }

    private void crearItem(Long donacionId, Long alimentoId, double cantidad, String unidad) {
        DonacionItem i = new DonacionItem();
        i.setDonacionId(donacionId);
        i.setAlimentoId(alimentoId);
        i.setCantidad(cantidad);
        i.setUnidad(unidad);
        donacionItemRepo.save(i);
    }

    private void crearLote(Long alimentoId, double cantidad, Long origen, LocalDate vencimiento, Long usuarioId) {
        Lote l = new Lote();
        l.setAlimentoId(alimentoId);
        l.setCantidad(cantidad);
        l.setCantidadInicial(cantidad);
        l.setOrigenDonacionId(origen);
        l.setVencimiento(vencimiento);
        l.setActivo(true);
        loteRepo.save(l);
        Movimiento m = new Movimiento();
        m.setTipo("ingreso");
        m.setAlimentoId(alimentoId);
        m.setLoteId(l.getId());
        m.setCantidad(cantidad);
        m.setDetalle(origen != null ? "Ingreso donacion #" + origen : "Carga inicial");
        m.setUsuarioId(usuarioId);
        movimientoRepo.save(m);
    }
}
