package com.sumaunplato.service;

import com.sumaunplato.dto.EntregaRequest;
import com.sumaunplato.dto.IngresoRequest;
import com.sumaunplato.model.Donacion;
import com.sumaunplato.model.Entrega;
import com.sumaunplato.model.EntregaItem;
import com.sumaunplato.model.Lote;
import com.sumaunplato.model.Movimiento;
import com.sumaunplato.model.Notificacion;
import com.sumaunplato.model.PlanillaNecesidad;
import com.sumaunplato.repository.DonacionRepository;
import com.sumaunplato.repository.EntregaItemRepository;
import com.sumaunplato.repository.EntregaRepository;
import com.sumaunplato.repository.LoteRepository;
import com.sumaunplato.repository.MovimientoRepository;
import com.sumaunplato.repository.NotificacionRepository;
import com.sumaunplato.repository.PlanillaNecesidadRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class DepositoService {

    private final LoteRepository loteRepo;
    private final DonacionRepository donacionRepo;
    private final EntregaRepository entregaRepo;
    private final EntregaItemRepository entregaItemRepo;
    private final MovimientoRepository movimientoRepo;
    private final PlanillaNecesidadRepository planillaRepo;
    private final NotificacionRepository notificacionRepo;

    public DepositoService(LoteRepository loteRepo, DonacionRepository donacionRepo,
                           EntregaRepository entregaRepo, EntregaItemRepository entregaItemRepo,
                           MovimientoRepository movimientoRepo, PlanillaNecesidadRepository planillaRepo,
                           NotificacionRepository notificacionRepo) {
        this.loteRepo = loteRepo;
        this.donacionRepo = donacionRepo;
        this.entregaRepo = entregaRepo;
        this.entregaItemRepo = entregaItemRepo;
        this.movimientoRepo = movimientoRepo;
        this.planillaRepo = planillaRepo;
        this.notificacionRepo = notificacionRepo;
    }

    public static int ordenFefo(Lote a, Lote b) {
        LocalDate va = a.getVencimiento();
        LocalDate vb = b.getVencimiento();
        if (va == null && vb == null) {
            return Long.compare(a.getId(), b.getId());
        }
        if (va == null) {
            return 1;
        }
        if (vb == null) {
            return -1;
        }
        int comparacion = va.compareTo(vb);
        return comparacion != 0 ? comparacion : Long.compare(a.getId(), b.getId());
    }

    public double stockPorAlimento(Long alimentoId) {
        double total = 0;
        for (Lote l : loteRepo.findByAlimentoIdAndActivoTrueAndCantidadGreaterThan(alimentoId, 0)) {
            total += l.getCantidad();
        }
        return total;
    }

    public double cubiertoNecesidad(Long alimentoId) {
        double total = 0;
        for (Lote l : loteRepo.findByAlimentoId(alimentoId)) {
            total += l.getCantidadInicial();
        }
        return total;
    }

    public void registrarMovimiento(String tipo, Long alimentoId, Long loteId, Double cantidad, String detalle, Long usuarioId) {
        Movimiento m = new Movimiento();
        m.setTipo(tipo);
        m.setAlimentoId(alimentoId);
        m.setLoteId(loteId);
        m.setCantidad(cantidad);
        m.setDetalle(detalle);
        m.setUsuarioId(usuarioId);
        m.setCreadoEn(LocalDateTime.now());
        movimientoRepo.save(m);
    }

    @Transactional
    public Donacion confirmarIngreso(IngresoRequest req) {
        Donacion donacion = donacionRepo.findById(req.getDonacionId()).orElseThrow();
        if (!donacion.getEstado().equals("registrada")) {
            throw new IllegalStateException("La donacion ya fue procesada");
        }
        for (IngresoRequest.IngresoItem it : req.getItems()) {
            if (it.getAlimentoId() == null || it.getCantidad() <= 0) {
                continue;
            }
            Lote lote = new Lote();
            lote.setAlimentoId(it.getAlimentoId());
            lote.setCantidad(it.getCantidad());
            lote.setCantidadInicial(it.getCantidad());
            lote.setOrigenDonacionId(donacion.getId());
            if (it.getVencimiento() != null && !it.getVencimiento().isEmpty()) {
                lote.setVencimiento(LocalDate.parse(it.getVencimiento()));
            }
            lote.setCreadoEn(LocalDateTime.now());
            lote.setActivo(true);
            loteRepo.save(lote);
            registrarMovimiento("ingreso", it.getAlimentoId(), lote.getId(), it.getCantidad(),
                    "Ingreso donacion #" + donacion.getId(), req.getUsuarioId());
        }
        donacion.setEstado("ingresada");
        donacion.setIngresadoEn(LocalDateTime.now());
        return donacionRepo.save(donacion);
    }

    @Transactional
    public Entrega prepararEntrega(EntregaRequest req) {
        Entrega entrega = new Entrega();
        entrega.setMerenderoId(req.getMerenderoId());
        entrega.setEstado("preparada");
        entrega.setCreadoEn(LocalDateTime.now());
        entregaRepo.save(entrega);

        boolean algo = false;
        Set<Long> donacionesAfectadas = new HashSet<>();

        for (EntregaRequest.EntregaCantidad pedido : req.getItems()) {
            double falta = pedido.getCantidad();
            if (falta <= 0) {
                continue;
            }
            Long alimentoId = pedido.getAlimentoId();

            List<Lote> lotes = new ArrayList<>(loteRepo.findByAlimentoIdAndActivoTrueAndCantidadGreaterThan(alimentoId, 0));
            lotes.sort(DepositoService::ordenFefo);

            double entregado = 0;
            for (Lote lote : lotes) {
                if (entregado >= falta) {
                    break;
                }
                double toma = Math.min(lote.getCantidad(), falta - entregado);
                if (toma <= 0) {
                    continue;
                }
                EntregaItem ei = new EntregaItem();
                ei.setEntregaId(entrega.getId());
                ei.setLoteId(lote.getId());
                ei.setAlimentoId(alimentoId);
                ei.setCantidad(toma);
                entregaItemRepo.save(ei);

                lote.setCantidad(lote.getCantidad() - toma);
                if (lote.getCantidad() <= 0) {
                    lote.setActivo(false);
                }
                loteRepo.save(lote);

                registrarMovimiento("egreso", alimentoId, lote.getId(), toma,
                        "Entrega #" + entrega.getId() + " a merendero #" + req.getMerenderoId(), req.getUsuarioId());

                entregado += toma;
                algo = true;
                if (lote.getOrigenDonacionId() != null) {
                    donacionesAfectadas.add(lote.getOrigenDonacionId());
                }
            }

            if (entregado > 0) {
                List<PlanillaNecesidad> planillas = planillaRepo
                        .findByMerenderoIdAndAlimentoIdAndEstadoNot(req.getMerenderoId(), alimentoId, "cubierta");
                if (!planillas.isEmpty()) {
                    PlanillaNecesidad p = planillas.get(0);
                    p.setEstado(entregado >= p.getCantidad() ? "cubierta" : "parcial");
                    planillaRepo.save(p);
                }
            }
        }

        if (!algo) {
            throw new IllegalStateException("No hay stock disponible para lo pedido");
        }

        for (Long donacionId : donacionesAfectadas) {
            Optional<Donacion> od = donacionRepo.findById(donacionId);
            if (od.isPresent() && od.get().getEstado().equals("ingresada")) {
                od.get().setEstado("asignada");
                donacionRepo.save(od.get());
            }
        }
        return entrega;
    }

    @Transactional
    public void recibirEntrega(Long entregaId, Long merenderoId) {
        Entrega entrega = entregaRepo.findById(entregaId).orElseThrow();
        if (!entrega.getMerenderoId().equals(merenderoId) || !entrega.getEstado().equals("preparada")) {
            throw new IllegalStateException("Entrega no valida");
        }
        entrega.setEstado("recibida");
        entrega.setEntregadoEn(LocalDateTime.now());
        entregaRepo.save(entrega);

        Set<Long> donaciones = new HashSet<>();
        for (EntregaItem ei : entregaItemRepo.findByEntregaId(entregaId)) {
            if (ei.getLoteId() == null) {
                continue;
            }
            Optional<Lote> ol = loteRepo.findById(ei.getLoteId());
            if (ol.isPresent() && ol.get().getOrigenDonacionId() != null) {
                donaciones.add(ol.get().getOrigenDonacionId());
            }
        }
        for (Long donacionId : donaciones) {
            Optional<Donacion> od = donacionRepo.findById(donacionId);
            if (od.isPresent() && (od.get().getEstado().equals("asignada") || od.get().getEstado().equals("ingresada"))) {
                od.get().setEstado("entregada");
                donacionRepo.save(od.get());
                Notificacion n = new Notificacion();
                n.setUsuarioId(od.get().getDonanteId());
                n.setMensaje("Gracias! Tu aporte ya llego a un merendero de la red y hoy hay comida en la mesa.");
                n.setCreadoEn(LocalDateTime.now());
                notificacionRepo.save(n);
            }
        }
    }
}
