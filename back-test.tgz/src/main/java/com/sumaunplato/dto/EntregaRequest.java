package com.sumaunplato.dto;

import java.util.List;

public class EntregaRequest {

    private Long merenderoId;
    private Long usuarioId;
    private List<EntregaCantidad> items;

    public Long getMerenderoId() { return merenderoId; }
    public void setMerenderoId(Long merenderoId) { this.merenderoId = merenderoId; }

    public Long getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Long usuarioId) { this.usuarioId = usuarioId; }

    public List<EntregaCantidad> getItems() { return items; }
    public void setItems(List<EntregaCantidad> items) { this.items = items; }

    public static class EntregaCantidad {
        private Long alimentoId;
        private double cantidad;

        public Long getAlimentoId() { return alimentoId; }
        public void setAlimentoId(Long alimentoId) { this.alimentoId = alimentoId; }

        public double getCantidad() { return cantidad; }
        public void setCantidad(double cantidad) { this.cantidad = cantidad; }
    }
}
