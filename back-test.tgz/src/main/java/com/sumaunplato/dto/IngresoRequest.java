package com.sumaunplato.dto;

import java.util.List;

public class IngresoRequest {

    private Long donacionId;
    private Long usuarioId;
    private List<IngresoItem> items;

    public Long getDonacionId() { return donacionId; }
    public void setDonacionId(Long donacionId) { this.donacionId = donacionId; }

    public Long getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Long usuarioId) { this.usuarioId = usuarioId; }

    public List<IngresoItem> getItems() { return items; }
    public void setItems(List<IngresoItem> items) { this.items = items; }

    public static class IngresoItem {
        private Long alimentoId;
        private double cantidad;
        private String vencimiento;

        public Long getAlimentoId() { return alimentoId; }
        public void setAlimentoId(Long alimentoId) { this.alimentoId = alimentoId; }

        public double getCantidad() { return cantidad; }
        public void setCantidad(double cantidad) { this.cantidad = cantidad; }

        public String getVencimiento() { return vencimiento; }
        public void setVencimiento(String vencimiento) { this.vencimiento = vencimiento; }
    }
}
